<?PHP function getFileList($dir) { 
	// array to hold return value $retval = array(); 
	// add trailing slash if missing if(substr($dir, -1) != "/") $dir .= "/"; 
	// open pointer to directory and read list of files 
	$d = @dir($dir) or die("getFileList: Failed opening directory $dir for reading");
	while(false !== ($entry = $d->read())) {
		// skip hidden files 
		if($entry[0] == ".") continue; 
		if(is_dir("$dir$entry")) { 
			$retval[] = array( "name" => "$dir$entry/", 
					"type" => filetype("$dir$entry"), 
					"size" => 0, 
					"lastmod" => filemtime("$dir$entry") ); 
		} 
		elseif(is_readable("$dir$entry")) { 
			$retval[] = array( "name" => "$dir$entry", 
					//"type" => mime_content_type("$dir$entry"), 
					"size" => filesize("$dir$entry"), 
					"lastmod" => filemtime("$dir$entry") ); 
		} 
	} 
	$d->close(); 
	return $retval; 
} ?>


<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Experiment-10</title>
<script src="js/raphael.js"></script>



<script src="js/jquery-1.7.1.min.js"></script>

<script>
	Array.prototype.max = function() {
		var max = this[0];
		var len = this.length;
		for (var i = 1; i < len; i++) if (this[i] > max) max = this[i];
		return max;
	}
	
	Array.prototype.min = function() {
		var min = this[0];
		var len = this.length;
		for (var i = 1; i < len; i++) if (this[i] < min) min = this[i];
		return min;
	}

	function roundNumber(num, dec) {
		var result = Math.round(num*Math.pow(10,dec))/Math.pow(10,dec);
		return result;
	}

	var data;
	
	function show_table(add){
		if (typeof add == "undefined")
			add = 0;
		else if (add == "")
			add=0;
		var lines=data.split('\n');
		var tab="<tr class='header'><td width='100'>B-V</td><td width='100'>m<sub>v</sub></td><td width='100'>Modified</td></tr>";
		var entry=null;
		for (var i=4; i<lines.length; i++){
			//console.log(lines[i].replace(/\s{2,}/g, ' ').split("\\s+"));
			entry=lines[i].replace(/\s{2,}/g, ',').split(',');
			tab+="<tr><td class='x'>"+entry[3]+"</td><td>"+entry[2]+"</td><td class='y'>"+roundNumber(parseFloat(entry[2])+add,2)+"</td></tr>";
		}
		$("#data_table").html(tab);
		plot();
	}
	
	function plot(){
		// Creates canvas 320 � 200 at 10, 50
		var paper = Raphael("holder", 600, 600);
		
		var x=Array();
		var y=Array();
		$(".x").each(function(){x.push(parseFloat($(this).html()))});
		$(".y").each(function(){y.push(parseFloat($(this).html()))});

		if (x.length!=y.length){
			alert("Bad data: mV and B-V have different number of entries");
			return;
		}
		
		console.log(x.min()+' '+x.max());
		for (var i=0; i<x.length; i++){
			// Creates circle at x = 50, y = 40, with radius 10
			var circle = paper.circle(x[i], y[i], 2);
			// Sets the fill attribute of the circle to red (#f00)
			circle.attr("fill", "black");
			// Sets the stroke attribute of the circle to white
			circle.attr("stroke", "#fff");
		}
	}
	
	$(document).ready(function(){
		$("option").click(function(){
			// Assign handlers immediately after making the request,
			// and remember the jqxhr object for this request
			if ($(this).val()!=0){;
				var jqxhr = $.get("Star_Database/"+encodeURIComponent(this.innerHTML)+".txt", function(local_data) {
					data=local_data
					$("#add_value").val("0");
					show_table();
				})
				//.success(function() { alert("second success"); })
				.error(function() { alert("error"); })
				//.complete(function() { alert("complete"); });
			}

		});
		
		$("#add_button").click(function(){
			show_table(parseFloat($("#add_value").val()));
		});
	});
</script>

<style>
	.header{
		font-weight:bold;
	}
	td {
		border:1px solid black;
	}
body {
	background-color: #FFFFCC;
}
</style>

</head>
<body>
<select>
 <option value="0">... Select Data File ..</option>
 <?php

	$dirlist = getFileList("Star_Database/");
	$num_files = count($dirlist);
	for ($i=0; $i<$num_files; $i++){
		if (strtolower(substr($dirlist[$i]["name"], -4))==".txt")
			echo '<option value="',$i+1,'">',substr(substr($dirlist[$i]["name"], 14),0,-4),'</option>';
	}
?>
</select>
<br>
<br>

cvdhjfsghj<input id="add_value"/> <button id="add_button">Add</button><br/>

<div style="width:50%; float:left;">
<table id="data_table" cellspacing="1" cellpadding="5" style="text-align:center; display:inline-block">
<tr class="header"><td width="100">m<sub>v</sub></td><td width="100">B-V</td><td width="100">Modified</td></tr>
</table>
</div>

<div id="holder" style="width:50%; float:right; width:200px; height:100px; border:1px solid black;"></div>

</body>
</html>
